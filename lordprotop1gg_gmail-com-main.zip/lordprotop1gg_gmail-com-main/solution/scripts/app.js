

const STORAGE = {
  PRODUCTS: 'products',
  CART: 'cart',
  PROFILE: 'profile',
  ORDERS: 'orders',
  THEME: 'theme'
};

const SKELETON_TIME = 1500;
const ACTION_DELAY = 2000;



const qs = (s, r = document) => r.querySelector(s);
const qsa = (s, r = document) => [...r.querySelectorAll(s)];

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const formatPrice = (n) =>
  `$${Number(n).toLocaleString('en-US')}`;

const getParam = (name) =>
  new URLSearchParams(location.search).get(name);

const setParams = (params) => {
  const url = new URL(location.href);
  Object.entries(params).forEach(([k, v]) => {
    if (!v) url.searchParams.delete(k);
    else url.searchParams.set(k, v);
  });
  history.replaceState(null, '', url);
};


const themeToggle = qs('[data-test-id="theme-toggle"]');
if (themeToggle) {
  themeToggle.textContent =
    document.documentElement.classList.contains('dark-theme') ? '☀️' : '🌙';

  themeToggle.onclick = () => {
    document.documentElement.classList.toggle('dark-theme');
    const dark = document.documentElement.classList.contains('dark-theme');
    localStorage.setItem(STORAGE.THEME, dark ? 'dark' : 'light');
    themeToggle.textContent = dark ? '☀️' : '🌙';
  };
}



function updateCartBadge() {
  const badge = qs('[data-test-id="cart-badge"]');
  if (!badge) return;

  const cart = JSON.parse(localStorage.getItem(STORAGE.CART) || '[]');
  badge.textContent = cart.length;
  badge.classList.toggle('hidden', cart.length === 0);
}

updateCartBadge();



async function loadProducts() {
  let products = JSON.parse(localStorage.getItem(STORAGE.PRODUCTS));
  if (products) return products;

  try {
    const res = await fetch('./data.json');
    products = await res.json();
    localStorage.setItem(STORAGE.PRODUCTS, JSON.stringify(products));
    return products;
  } catch {
    return null;
  }
}



function showSkeletons() {
  const list = qs('[data-test-id="product-list"]');
  list.innerHTML = '';
  for (let i = 0; i < 8; i++) {
    const s = document.createElement('div');
    s.className = 'skeleton-card';
    s.dataset.testId = 'skeleton-card';
    list.appendChild(s);
  }
}


function isBought(id) {
  const orders = JSON.parse(localStorage.getItem(STORAGE.ORDERS) || '[]');
  return orders.some(o => o.items.some(i => i.id === id));
}

function renderProducts(products) {
  const list = qs('[data-test-id="product-list"]');
  list.innerHTML = '';

  products.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.dataset.testId = 'product-card';

    if (isBought(p.id)) {
      card.classList.add('bought');
      const badge = document.createElement('div');
      badge.className = 'bought-badge';
      badge.textContent = 'BOUGHT';
      card.appendChild(badge);
    }

    card.innerHTML += `
      <img src="${p.image}" alt="">
      <div class="product-info">
        <div data-test-id="product-type" class="product-type">${p.type}</div>
        <div data-test-id="product-title" class="product-title">${p.title}</div>
        <div data-test-id="product-price" class="product-price">${formatPrice(p.price)}</div>
      </div>
    `;

    if (!card.classList.contains('bought')) {
      card.onclick = () => openModal(p);
    }

    list.appendChild(card);
  });
}


let activeFilters = [];
let searchValue = '';

function applyFilters(products) {
  return products.filter(p => {
    if (activeFilters.length && !activeFilters.includes(p.type)) return false;
    if (searchValue && !p.title.toLowerCase().includes(searchValue.toLowerCase())) return false;
    return true;
  });
}

function initFilters(products) {
  const filters = qsa('[data-test-id="filter"]');

  const fromUrl = getParam('filters');
  if (fromUrl) {
    activeFilters = fromUrl.split(',');
    filters.forEach(f => {
      if (activeFilters.includes(f.dataset.type)) f.classList.add('active');
    });
  }

  filters.forEach(btn => {
    btn.onclick = () => {
      btn.classList.toggle('active');
      activeFilters = filters
        .filter(f => f.classList.contains('active'))
        .map(f => f.dataset.type);

      setParams({ filters: activeFilters.join(',') || null });
      renderProducts(applyFilters(products));
    };
  });
}



const searchInput = qs('[data-test-id="search-input"]');
const suggestions = qs('[data-test-id="search-suggestions"]');

function initSearch(products) {
  const fromUrl = getParam('search');
  if (fromUrl) {
    searchInput.value = fromUrl;
    searchValue = fromUrl;
  }

  searchInput.oninput = async () => {
    searchValue = searchInput.value;
    suggestions.innerHTML = 'Loading...';
    suggestions.classList.remove('hidden');

    await sleep(SKELETON_TIME);

    const items = products
      .filter(p => p.title.toLowerCase().includes(searchValue.toLowerCase()))
      .sort((a, b) => a.title.localeCompare(b.title))
      .slice(0, 3);

    suggestions.innerHTML = '';
    items.forEach(p => {
      const el = document.createElement('div');
      el.className = 'suggestion-item';
      el.dataset.testId = 'suggestion-item';
      el.textContent = p.title;
      el.onclick = () => {
        activeFilters = [];
        qsa('[data-test-id="filter"]').forEach(f => f.classList.remove('active'));
        searchInput.value = p.title;
        searchValue = p.title;
        setParams({ filters: null, search: p.title });
        suggestions.classList.add('hidden');
        renderProducts(applyFilters(products));
        if (!isBought(p.id)) openModal(p);
      };
      suggestions.appendChild(el);
    });
  };

  searchInput.onkeydown = e => {
    if (e.key === 'Enter') {
      setParams({ search: searchValue || null });
      renderProducts(applyFilters(products));
      suggestions.classList.add('hidden');
    }
  };

  document.addEventListener('click', e => {
    if (!e.target.closest('.search')) suggestions.classList.add('hidden');
  });
}



const modal = qs('[data-test-id="modal"]');
const modalTitle = qs('[data-test-id="modal-title"]');
const modalDesc = qs('[data-test-id="modal-description"]');
const modalPrice = qs('[data-test-id="modal-price"]');
const modalImg = qs('.modal-image');
const modalBtn = qs('[data-test-id="add-to-cart"]');

let currentProduct = null;

function openModal(p) {
  currentProduct = p;
  modalTitle.textContent = p.title;
  modalDesc.textContent = p.description;
  modalPrice.textContent = formatPrice(p.price);
  modalImg.src = p.image;

  const cart = JSON.parse(localStorage.getItem(STORAGE.CART) || '[]');
  modalBtn.textContent = cart.some(i => i.id === p.id)
    ? 'Remove from cart'
    : 'Add to cart';

  modal.classList.remove('hidden');
}

qs('[data-test-id="modal-close"]').onclick = closeModal;
qs('.modal-overlay').onclick = closeModal;
document.onkeydown = e => e.key === 'Escape' && closeModal();

function closeModal() {
  modal.classList.add('hidden');
}



modalBtn.onclick = async () => {
  let cart = JSON.parse(localStorage.getItem(STORAGE.CART) || '[]');
  const exists = cart.some(i => i.id === currentProduct.id);

  modalBtn.disabled = true;

  if (!exists) {
    modalBtn.textContent = 'Added';
    cart.push(currentProduct);
    showToast('Great choice!');
    await sleep(ACTION_DELAY);
    modalBtn.textContent = 'Remove from cart';
  } else {
    modalBtn.textContent = 'Removed';
    cart = cart.filter(i => i.id !== currentProduct.id);
    showToast('Looking for something better?');
    await sleep(ACTION_DELAY);
    modalBtn.textContent = 'Add to cart';
  }

  localStorage.setItem(STORAGE.CART, JSON.stringify(cart));
  updateCartBadge();
  modalBtn.disabled = false;
};



function showToast(text) {
  const t = qs('.toast');
  t.textContent = text;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), ACTION_DELAY);
}



(async function init() {
  if (!qs('[data-test-id="product-list"]')) return;

  showSkeletons();
  const start = Date.now();
  const products = await loadProducts();

  if (!products) {
    qs('[data-test-id="product-list"]').textContent =
      'Failed to load products';
    return;
  }

  const diff = Date.now() - start;
  if (diff < SKELETON_TIME) await sleep(SKELETON_TIME - diff);

  initFilters(products);
  initSearch(products);
  renderProducts(applyFilters(products));
})();
